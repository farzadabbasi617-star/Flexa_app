import {
  pgTable,
  uuid,
  varchar,
  text,
  integer,
  timestamp,
  boolean,
  jsonb,
  pgEnum,
} from "drizzle-orm/pg-core";

// Site settings (admin-managed content)
export const siteSettings = pgTable("site_settings", {
  id: uuid("id").defaultRandom().primaryKey(),
  key: varchar("key", { length: 100 }).notNull().unique(),
  value: text("value"),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Site images (admin uploads)
export const siteImages = pgTable("site_images", {
  id: uuid("id").defaultRandom().primaryKey(),
  slug: varchar("slug", { length: 100 }).notNull().unique(),
  title: varchar("title", { length: 255 }).notNull(),
  url: text("url").notNull(),
  altText: varchar("alt_text", { length: 255 }),
  category: varchar("category", { length: 50 }).notNull().default("general"),
  sortOrder: integer("sort_order").notNull().default(0),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users table (for authentication)
export const users = pgTable("users", {
  id: uuid("id").defaultRandom().primaryKey(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  passwordHash: varchar("password_hash", { length: 255 }).notNull(),
  displayName: varchar("display_name", { length: 100 }).notNull(),
  avatarUrl: varchar("avatar_url", { length: 500 }),
  role: varchar("role", { length: 50 }).notNull().default("user"),
  isVerified: boolean("is_verified").notNull().default(false),
  // Game IDs for prize distribution
  clashRoyaleId: varchar("clash_royale_id", { length: 100 }),
  clashRoyaleUsername: varchar("clash_royale_username", { length: 100 }),
  codMobileId: varchar("cod_mobile_id", { length: 100 }),
  codMobileUsername: varchar("cod_mobile_username", { length: 100 }),
  fortniteId: varchar("fortnite_id", { length: 100 }),
  fortniteUsername: varchar("fortnite_username", { length: 100 }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  lastLoginAt: timestamp("last_login_at"),
});

// Sessions table
export const sessions = pgTable("sessions", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  token: varchar("token", { length: 255 }).notNull().unique(),
  expiresAt: timestamp("expires_at").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Notifications table
export const notifications = pgTable("notifications", {
  id: uuid("id").defaultRandom().primaryKey(),
  userId: uuid("user_id").notNull().references(() => users.id),
  type: varchar("type", { length: 50 }).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  link: varchar("link", { length: 500 }),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Teams table
export const teams = pgTable("teams", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  tag: varchar("tag", { length: 10 }).notNull(),
  logoUrl: varchar("logo_url", { length: 500 }),
  ownerId: uuid("owner_id").notNull().references(() => users.id),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Team members
export const teamMembers = pgTable("team_members", {
  id: uuid("id").defaultRandom().primaryKey(),
  teamId: uuid("team_id").notNull().references(() => teams.id),
  userId: uuid("user_id").notNull().references(() => users.id),
  role: varchar("role", { length: 50 }).notNull().default("member"),
  joinedAt: timestamp("joined_at").defaultNow().notNull(),
});

// Achievements table
export const achievements = pgTable("achievements", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 100 }).notNull(),
  nameFA: varchar("name_fa", { length: 100 }).notNull(),
  description: varchar("description", { length: 255 }).notNull(),
  descriptionFA: varchar("description_fa", { length: 255 }).notNull(),
  icon: varchar("icon", { length: 50 }).notNull(),
  category: varchar("category", { length: 50 }).notNull(),
  requirement: integer("requirement").notNull(),
  points: integer("points").notNull().default(10),
});

// User achievements
export const userAchievements = pgTable("user_achievements", {
  id: uuid("id").defaultRandom().primaryKey(),
  visibleUserId: uuid("user_id").notNull().references(() => users.id),
  achievementId: uuid("achievement_id").notNull().references(() => achievements.id),
  unlockedAt: timestamp("unlocked_at").defaultNow().notNull(),
});

export const gameEnum = pgEnum("game_type", [
  "clash_royale",
  "cod_mobile",
  "fortnite",
]);

export const tournamentStatusEnum = pgEnum("tournament_status", [
  "registration",
  "in_progress",
  "completed",
  "cancelled",
]);

export const matchStatusEnum = pgEnum("match_status", [
  "pending",
  "in_progress",
  "awaiting_judgment",
  "completed",
  "disputed",
]);

export const tournamentFormatEnum = pgEnum("tournament_format", [
  "single_elimination",
  "double_elimination",
  "round_robin",
]);

// Tournaments table
export const tournaments = pgTable("tournaments", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  game: gameEnum("game").notNull(),
  format: tournamentFormatEnum("format").notNull().default("single_elimination"),
  status: tournamentStatusEnum("status").notNull().default("registration"),
  description: text("description"),
  maxPlayers: integer("max_players").notNull().default(16),
  prizePool: varchar("prize_pool", { length: 100 }),
  entryFee: varchar("entry_fee", { length: 100 }).default("رایگان"),
  gameMode: varchar("game_mode", { length: 100 }),
  mapName: varchar("map_name", { length: 100 }),
  serverSlots: integer("server_slots").default(16),
  prize1st: varchar("prize_1st", { length: 100 }),
  prize2nd: varchar("prize_2nd", { length: 100 }),
  prize3rd: varchar("prize_3rd", { length: 100 }),
  prize4to10: varchar("prize_4to10", { length: 100 }),
  rules: text("rules"),
  bannerUrl: varchar("banner_url", { length: 500 }),
  createdById: uuid("created_by_id").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
  startDate: timestamp("start_date"),
});

// Players table
export const players = pgTable("players", {
  id: uuid("id").defaultRandom().primaryKey(),
  visibleUserId: uuid("user_id").references(() => users.id),
  username: varchar("username", { length: 100 }).notNull(),
  displayName: varchar("display_name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  avatarUrl: varchar("avatar_url", { length: 500 }),
  gameId: varchar("game_id", { length: 100 }),
  rating: integer("rating").notNull().default(1000),
  wins: integer("wins").notNull().default(0),
  losses: integer("losses").notNull().default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Tournament registrations
export const registrations = pgTable("registrations", {
  id: uuid("id").defaultRandom().primaryKey(),
  tournamentId: uuid("tournament_id").notNull().references(() => tournaments.id),
  playerId: uuid("player_id").notNull().references(() => players.id),
  visibleUserId: uuid("user_id").references(() => users.id),
  seed: integer("seed"),
  registeredAt: timestamp("registered_at").defaultNow().notNull(),
});

// Matches table
export const matches = pgTable("matches", {
  id: uuid("id").defaultRandom().primaryKey(),
  tournamentId: uuid("tournament_id").notNull().references(() => tournaments.id),
  round: integer("round").notNull(),
  matchNumber: integer("match_number").notNull(),
  player1Id: uuid("player1_id").references(() => players.id),
  player2Id: uuid("player2_id").references(() => players.id),
  winnerId: uuid("winner_id").references(() => players.id),
  player1Score: integer("player1_score"),
  player2Score: integer("player2_score"),
  status: matchStatusEnum("status").notNull().default("pending"),
  scheduledAt: timestamp("scheduled_at"),
  completedAt: timestamp("completed_at"),
  evidence: jsonb("evidence"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Match evidence
export const matchEvidence = pgTable("match_evidence", {
  id: uuid("id").defaultRandom().primaryKey(),
  matchId: uuid("match_id").notNull().references(() => matches.id),
  uploadedById: uuid("uploaded_by_id").notNull().references(() => users.id),
  fileUrl: varchar("file_url", { length: 500 }).notNull(),
  fileType: varchar("file_type", { length: 50 }).notNull(),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Chat messages table
export const chatMessages = pgTable("chat_messages", {
  id: uuid("id").defaultRandom().primaryKey(),
  senderId: uuid("sender_id").notNull().references(() => users.id),
  receiverId: uuid("receiver_id").references(() => users.id),
  tournamentId: uuid("tournament_id").references(() => tournaments.id),
  matchId: uuid("match_id").references(() => matches.id),
  message: text("message").notNull(),
  isRead: boolean("is_read").notNull().default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Judges table
export const judges = pgTable("judges", {
  id: uuid("id").defaultRandom().primaryKey(),
  visibleUserId: uuid("user_id").references(() => users.id),
  name: varchar("name", { length: 100 }).notNull(),
  email: varchar("email", { length: 255 }),
  role: varchar("role", { length: 50 }).notNull().default("judge"),
  isActive: boolean("is_active").notNull().default(true),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Judgments table
export const judgments = pgTable("judgments", {
  id: uuid("id").defaultRandom().primaryKey(),
  matchId: uuid("match_id").notNull().references(() => matches.id),
  judgeId: uuid("judge_id").references(() => judges.id),
  isAiJudgment: boolean("is_ai_judgment").notNull().default(false),
  verdict: varchar("verdict", { length: 50 }).notNull(),
  reasoning: text("reasoning"),
  confidence: integer("confidence"),
  scoreBreakdown: jsonb("score_breakdown"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Disputes table
export const disputes = pgTable("disputes", {
  id: uuid("id").defaultRandom().primaryKey(),
  matchId: uuid("match_id").notNull().references(() => matches.id),
  raisedById: uuid("raised_by_id").notNull().references(() => players.id),
  reason: text("reason").notNull(),
  evidenceUrls: jsonb("evidence_urls"),
  status: varchar("status", { length: 50 }).notNull().default("open"),
  resolution: text("resolution"),
  resolvedById: uuid("resolved_by_id").references(() => judges.id),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  resolvedAt: timestamp("resolved_at"),
});
